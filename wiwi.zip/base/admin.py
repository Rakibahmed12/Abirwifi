from django.contrib import admin
from .models import passs
from .models import camp
# Register your models here.
admin.site.register(passs)
admin.site.register(camp)