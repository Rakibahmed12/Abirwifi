from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('', views.main),
    path("add/",views.add),
    path("camp",views.camp),
    path("view/",views.view),
    path("login/",views.login)
]
