from django.shortcuts import render
from django.shortcuts import HttpResponse,redirect
from .models import passs
from .models import camp as campsss
import datetime
def main(req):
    try:
        req.COOKIES["login"]
    except:
        print("no")
        return redirect("/login")
    camps=list(campsss.objects.all().values())
    passss = passs.objects.all().values()
    ev = list(passss) 
    camps=list(campsss.objects.all().values())
    rows={}
    for s in camps:
        rows[s["name"]]=[]
        for a in ev:
            if a["camp"]==s["name"]:
                rows[s["name"]].append([a])
    
    val = {"rows":rows,"camps":camps}
    print(rows)
    
    return render(req,"index.html",val )
  
def add(req):
    try:
        req.COOKIES["login"]
    except:
        return redirect("/login")
    camps=list(campsss.objects.all().values())
    val = {"camps":camps}
    print(camps)
    if req.method == "POST":
        name = req.POST.get("w-name")
        pas = req.POST.get("w-pass")
        campv = req.POST.get("camp")
        print(campv)
        floor = int(req.POST.get("floor"))
        hi = passs(name=name,password=pas,camp=campv,floor=floor)
        hi.save()
        return redirect("/")
    return render(req,"add.html",val)
def camp(req):
    render("camp.html")

def view(req):
    id=int(req.GET.get("id"))
    passss = passs.objects.filter(id=id).values()
    ev = list(passss) 
    val = {"val":ev}
    return render(req,"view.html",val)
def login(req):
    if req.method == "POST":
        done = redirect("/")
        password = req.POST.get("password")
        if password == "Abirahmed333@":
            done.set_cookie("login","yes",expires=datetime.datetime.today()+datetime.timedelta(days=30))
            return done
    return render(req,"login.html")