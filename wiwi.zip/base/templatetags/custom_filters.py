from django import template

register = template.Library()

@register.filter(name='get_index')
def get_index(lst, index):
    try:
        return lst[index]
    except (IndexError, TypeError):
        return None